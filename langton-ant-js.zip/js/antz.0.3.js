// ANTZ: Langton's ant script for P5.js
// CM, April 2024 - happy Songkran
// version: 0.3

// globals
let ant;
let ant_size, corner_radius;
let color_ant, color_back, color_back_RGBA;
let pixel_fill, pixel_stroke;

let myCanvas = null;

let isRunning = false;
let inProcess = false;
let frame_rate = 4;
let fc = 0;
let iW = window.innerWidth;
let iH = window.innerHeight * 0.8;

let cycles = 0;

let initialEQ = ['D','F','R']
let initialNEQ = ['U','F','L']

const N = 0, E = 1, S = 2, W = 3;

// a simple ant object: this version of the script only handles one ant simultaneously
// but this can be easily improved
function Ant()  {
    this.guid = uuidv4();
    this.name = getAntName();
    this.size = 8;
    this.corner_radius = 0;
    this.color_fill = null;
    this.color_stroke = null;  
    this.pixel_fill = null;
    this.pixel_stroke = null;
    this.pixel_rgba = [];
    this.x = (iW / 2);
    this.y = (iH / 2);
    this.heading = random([0,1,2,3]);
    this.pen = 1;
    // command queue
    this.cQ =  [];
    // program for pixel = back_color
    this.pEQ =  initialEQ;
    this.ptrEQ = 0;
    // program for pixel != back_color
    this.pNEQ =  initialNEQ;
    this.ptrNEQ = 0; 
    this.x_pixel = null;
    this.y_pixel = null;
    this.isRunning = false;
}

// window onload
window.addEventListener('load',function() {
  //alert('Click to Start');
})

// JS event listener for 'resize'
function windowResized() {
  iW = window.innerWidth;
  iH = window.innerHeight * 0.8;  
  resizeCanvas(iW, iH);
}

function setup() {
    // initialise things around here
    colorMode(RGB);

    // create and attach the canvas to DOM
    myCanvas = createCanvas(iW, iH);  
    myCanvas.parent('canvasDiv');
    color_back = 140;
    color_back_RGBA = [color_back, color_back, color_back, 255];
    background(color_back);
    frameRate(frame_rate);

    // get a new ant
    ant = new Ant();
    color_ant = random(['aqua', 'black', 'blue', 'fuchsia', 'green', 'lime', 'maroon', 'navy', 'olive', 'purple', 'red', 'teal', 'white', 'yellow']);
    ant.color_stroke = color_ant;
    ant.color_fill = color_ant;    

    ant.ptrEQ = ant.pEQ.length;
    ant.ptrNEQ = ant.pNEQ.length;

    setPixel(ant);

}

function draw() {

  // the animation loop

  if (ant.isRunning == true) {
    cycles += 1;
    ix = (cycles % ant.ptrEQ);

    if (ant.pen == 0)  {
      fill(color_back);
      stroke(color_back);
      //console.log('pen up');    
    }

    if (ant.pen == 1)  {
      fill(ant.color_fill);
      stroke(color_back);    
      //console.log('pen down');
    }

    square( ant.x, ant.y, ant.size, ant.corner_radius );    

    // ant reads the environment here
    ant.pixel_rgba = get(ant.x_pixel, ant.y_pixel);    
    // and decides here
    if (JSON.stringify(ant.pixel_rgba) === JSON.stringify(color_back_RGBA)) 
        p5_pushCmd(ant.pEQ[ix]);
    else 
        p5_pushCmd(ant.pNEQ[ix]);

    // the following 3 lines control "the pixel": ie, visual of the next move of the ant
    //fill(ant.pixel_fill);
    //stroke(ant.pixel_stroke);
    //circle( ant.x_pixel, ant.y_pixel, 2);

    setPixel(ant);    
    
    c = p5_getCmd(ant);

    // parse commands
    if (c!==null) 
    {
      if (c=='F') { moveForward(ant); }
      if (c=='B') { moveBackward(ant); }      
      if (c=='R') { rotateRight(ant); }
      if (c=='L') { rotateLeft(ant); }
      if (c=='U') { penUp(ant); }
      if (c=='D') { penDown(ant); }                            
    }     

    p5_updateCounter(cycles);
  }
  else  {
    // console.log('loop stop');
  }      
}

// moveForward, move 1 "size block" depending on heading
function moveForward(_ant){   

  if (_ant.heading==E){
    _ant.x = _ant.x + _ant.size;
  }
  if (_ant.heading==W){
    _ant.x = _ant.x - _ant.size;
  }    
  if (_ant.heading==S){
    _ant.y = _ant.y + _ant.size;
  }
  if (_ant.heading==N){
    _ant.y = _ant.y - _ant.size;
  }
}

// moveBackward, move -1 "size block" depending on heading
function moveBackward(_ant){
  if (_ant.heading==E){
    _ant.x = _ant.x - _ant.size;
  }
  if (_ant.heading==W){
    _ant.x = _ant.x + _ant.size;
  }    
  if (_ant.heading==S){
    _ant.y = _ant.y - _ant.size;
  }
  if (_ant.heading==N){
    _ant.y = _ant.y + _ant.size;
  }
}

function rotateRight(_ant){
  _ant.heading ++;
  if (_ant.heading > 3) { _ant.heading = 0 };
  setPixel(_ant);
}
function rotateLeft(_ant){
  _ant.heading --;
  if (_ant.heading < 0 ) { _ant.heading = 3 };
  setPixel(_ant);  
}

function penUp(_ant){
  _ant.pen = 0;
}

function penDown(_ant){
    _ant.pen = 1; 
}

// update the target pixel position relative to the ant's rotation
function setPixel(_ant) {
    if (_ant.heading==E){
      _ant.x_pixel = (_ant.x + _ant.size) + (_ant.size / 2);
      _ant.y_pixel = (_ant.y) + (_ant.size / 2);
    }
    if (_ant.heading==W){
      _ant.x_pixel = (_ant.x) - (_ant.size / 2);
      _ant.y_pixel = (_ant.y) + (_ant.size / 2);
    }    
    if (_ant.heading==S){
      _ant.x_pixel = (_ant.x) + (_ant.size / 2);
      _ant.y_pixel = (_ant.y + _ant.size) + (_ant.size / 2);
    }
    if (_ant.heading==N){
      _ant.x_pixel = (_ant.x) + (_ant.size / 2);
      _ant.y_pixel = (_ant.y) - (_ant.size / 2);
    }
}

function randomColor() {
  let cl = "#";
  let r;
  for (let i = 0; i < 6; i++) {
    r = random(['0','1','2','3','4','5','6','7','8','9','a','b','c','d','e','f']);  
    cl += r;
  }
  console.log(cl);
  return cl;
}

// from https://www.geeksforgeeks.org/how-to-create-a-guid-uuid-in-javascript/
function uuidv4() {
    return 'xxxxxxxx-xxxx-xxxx-yxxx-xxxxxxxxxxxx'
    .replace(/[xy]/g, function (c) {
        const r = Math.random() * 16 | 0, 
            v = c == 'x' ? r : (r & 0x3 | 0x8);
        return v.toString(16);
    });
}

function getAntName() {
  let f = random(['Alice','Bob','Charlie','Dana','Emilio','Francine','Gus','Heloise','Ivan','Joan','Kazoku','Laura']);
  let u = uuidv4();
  return f + '-' + u.substring(u.length - 4) ;
}

// p5 interfaces with DOM / window components

function p5_run() {
  if (ant.isRunning == false) {
    // uncomment this line to erase canvas after stop/start
    //background(color_back);
    ant.isRunning = true;
    document.getElementById("btn_o").innerText=' Stop ';  
  }
  else  {
    ant.isRunning = false;
    document.getElementById("btn_o").innerText=' Play ';        
  }
}

function p5_pushCmd(_command) {
  ant.cQ.push(_command);
}

function p5_updateCounter(fc) {
      document.getElementById("frame_counter").innerText=fc;  
}

function p5_saveCanvas() {
    saveCanvas(myCanvas, ant.name);
}

// retrieve command
function p5_getCmd(_ant) {
  if (_ant.cQ.length > 0) {
    _cmd = (_ant.cQ.shift());    // queue
//  _cmd = (_ant.cQ.pop());      // stack 
  } else {
    _cmd = null;
  }
  return _cmd
}

// clear canvas
function p5_cls() {
    cycles = 0;
    background(color_back);
    p5_updateCounter(0);
  }

// log to console
function p5_debug() {
  console.log('\nDebug: ');
  console.log(ant); 
}