// ANTS: Langton's ant script for P5.js
// CM, April - May 2024 - happy Songkran
// version: 0.5

// globals
let ant, a_new_ant;
let color_ant, color_back, color_back_RGBA;
let pixel_fill, pixel_stroke;

let systemRunning = false;
let myCanvas = null;

let frame_rate = 16;
let iW = window.innerWidth;
let iH = window.innerHeight;
let oH = (iH / 2);
let oW = (iW / 2);

let ant_queue = [];
let cycles = 0;
// 2% of an ant going to sleep
let chance_sleep = 0.02;

const N = 0, E = 1, S = 2, W = 3;

// a simple ant
// the behaviours (commands) are stored in two queues
// EQ: the next square is the colour of the background
// NEQ: the next square is not the colour of the background
class Ant {
    constructor()   {
        this.guid = uuidv4();
        this.name = getAntName();
        this.size = 8;
        this.corner_radius = 0;
        //this.color_fill = random(['aqua', 'black', 'blue', 'fuchsia', 'green', 'lime', 'maroon', 'navy', 'olive', 'purple', 'red', 'teal', 'white', 'yellow']);
        this.color_fill = randomColor();
        this.color_stroke = this.color_fill;
        this.pixel_fill = null;
        this.pixel_stroke = null;
        this.pixel_rgba = [];
        this.x = Math.ceil(random(0,iW) / 10) * 10;
        this.y = Math.ceil(random(0,iH) / 10) * 10;
        this.heading = random([0,1,2,3]);
        this.pen = 1;
        // program for pixel = back_color
        this.pEQ =  getProgram("EQ");
        // program for pixel != back_color
        this.pNEQ =  getProgram("NEQ");
        this.x_pixel = null;
        this.y_pixel = null;
        this.awake = true;
    }   
}

// window onload
window.addEventListener('load',function() {
    const options = null;
    const mModal = new bootstrap.Modal(document.getElementById('mainModal'), options);

    // comment for splash modal
    mModal.show();
});

// JS event listener for 'resize'
function windowResized() {
  resizeCanvas(window.innerWidth, window.innerHeight);
}

function setup() {
    // initialise things around here
    colorMode(RGB);
    // create and attach the canvas to DOM
    myCanvas = createCanvas(iW, iH);
    myCanvas.parent('canvasDiv');
    color_back = 190;
    color_back_RGBA = [color_back, color_back, color_back, 255];
    background(color_back);
    frameRate(frame_rate);
}

// the animation loop of a P5js script
function draw() {
    if (ant_queue.length > 0) {
        ant_queue.forEach(animate);
        // some basic stats
        document.getElementById("frame_counter").innerText=cycles;
        document.getElementById("ant_counter").innerText=ant_queue.length;
    }
}

// animate: read the ant queue and move the next available ant
function animate(_ant)   {
    if (systemRunning == true) {
        cycles += 1;

        if (Math.random() < chance_sleep) { _ant.awake = false; };

        if (_ant.awake == true) {

            ixEQ = (cycles % _ant.pEQ.length);
            ixNEQ = (cycles % _ant.pNEQ.length);

            // ant reads the environment here
            _ant.pixel_rgba = get(_ant.x_pixel, _ant.y_pixel);

            if (JSON.stringify(_ant.pixel_rgba) === JSON.stringify(color_back_RGBA)) {
              c = _ant.pEQ[ixEQ];
            }
            else {
              c = _ant.pNEQ[ixNEQ];
            }            

            // parse commands
            if (c !== null) {
                if (c=='F') { moveForward(_ant) };
                if (c=='B') { moveBackward(_ant) };
                if (c=='R') { rotateRight(_ant) };
                if (c=='L') { rotateLeft(_ant) };
                if (c=='U') { _ant.pen = 0 };
                if (c=='D') { _ant.pen = 1 };
            };

            if (_ant.pen == 0)  {
              fill(color_back);
              stroke(color_back);
            } else {
                fill(_ant.color_fill);
                stroke(color_back);                           
            }              

            square( _ant.x, _ant.y, _ant.size, _ant.corner_radius );

        } else {
          // program for pixel = back_color
          _ant.pEQ =  getProgram("EQ");
          // program for pixel != back_color
          _ant.pNEQ =  getProgram("NEQ");
          _ant.awake = true;          
        }
    }

}

// moveForward, move 1 "size block" depending on heading
function moveForward(_ant){

  if (_ant.heading==E){
    _ant.x = _ant.x + _ant.size;
  }
  if (_ant.heading==W){
    _ant.x = _ant.x - _ant.size;
  }
  if (_ant.heading==S){
    _ant.y = _ant.y + _ant.size;
  }
  if (_ant.heading==N){
    _ant.y = _ant.y - _ant.size;
  }
  setPixel(_ant);  
}

// moveBackward, move -1 "size block" depending on heading
function moveBackward(_ant){
  if (_ant.heading==E){
    _ant.x = _ant.x - _ant.size;
  }
  if (_ant.heading==W){
    _ant.x = _ant.x + _ant.size;
  }
  if (_ant.heading==S){
    _ant.y = _ant.y - _ant.size;
  }
  if (_ant.heading==N){
    _ant.y = _ant.y + _ant.size;
  }
  setPixel(_ant);  
}

function rotateRight(_ant){
  _ant.heading ++;
  if (_ant.heading > 3) { _ant.heading = 0 };
  setPixel(_ant);
}
function rotateLeft(_ant){
  _ant.heading --;
  if (_ant.heading < 0 ) { _ant.heading = 3 };
  setPixel(_ant);
}

// update the target pixel position relative to the ant's rotation
function setPixel(_ant) {
    if (_ant.heading==E){
      _ant.x_pixel = (_ant.x + _ant.size) + (_ant.size / 2);
      _ant.y_pixel = (_ant.y) + (_ant.size / 2);
    }
    if (_ant.heading==W){
      _ant.x_pixel = (_ant.x) - (_ant.size / 2);
      _ant.y_pixel = (_ant.y) + (_ant.size / 2);
    }
    if (_ant.heading==S){
      _ant.x_pixel = (_ant.x) + (_ant.size / 2);
      _ant.y_pixel = (_ant.y + _ant.size) + (_ant.size / 2);
    }
    if (_ant.heading==N){
      _ant.x_pixel = (_ant.x) + (_ant.size / 2);
      _ant.y_pixel = (_ant.y) - (_ant.size / 2);
    }
}

function randomColor() {
  let cl = "#";
  let r;
  for (let i = 0; i < 6; i++) {
    r = random(['0','1','2','3','4','5','6','7','8','9','a','b','c','d','e','f']);
    cl += r;
  }
  //console.log(cl);
  return cl;
}

// from https://www.geeksforgeeks.org/how-to-create-a-guid-uuid-in-javascript/
function uuidv4() {
    return 'xxxxxxxx-xxxx-xxxx-yxxx-xxxxxxxxxxxx'
    .replace(/[xy]/g, function (c) {
        const r = Math.random() * 16 | 0,
            v = c == 'x' ? r : (r & 0x3 | 0x8);
        return v.toString(16);
    });
}

function getProgram(_mode) {
  let s;
  if (_mode == "EQ")  {
    s = random(['D,F,R,F','D,F,L,F']);
  }
  if (_mode == "NEQ")  {
    s = random(['U,B,L,B','U,B,R,B']);
  }
  const v = s.split(',');
  return v
}

function getAntName() {
  let f = random(['Alice','Bob','Carmen','Dino','Emilie','Fritz','Gigi','Hanno','Imogen','Jasmine']);
  let u = uuidv4();
  return f + '-' + u.substring(u.length - 4) ;
}

// p5 interfaces with DOM / window components

function p5_run() {
  if (systemRunning == false) {
    // uncomment this line to erase the canvas after stop/start
    //background(color_back);
    systemRunning = true;
    document.getElementById("btn_o").innerText=' Stop ';
  }
  else  {
    systemRunning = false;
    document.getElementById("btn_o").innerText=' Run ';
  }
}

function p5_newAnt()    {
    a_new_ant = new Ant();
    ant_queue.push(a_new_ant);
    let msgalert = ' An ant has arrived... ' + a_new_ant.name;
    alert(msgalert);
}

function p5_saveCanvas() {
    let filename = uuidv4();
    saveCanvas(myCanvas, filename);
}

// clear canvas
function p5_cls() {
    cycles = 0;
    background(color_back);
}

// log to console
function p5_debug() {
  console.log('\nDebug: ');
  console.log('\nAnt(s): ' + ant_queue.length.toString())
  console.log(ant_queue);
}

// target for "Start" in the Modal (see load event)
function p5_start() {
    p5_newAnt();
}
